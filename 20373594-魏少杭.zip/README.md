# 模式识别大作业
运行main.py文件，可以进行基于OpenCV的图像特征匹配和融合。

运行sift.py文件，可以得到部分的python实现的SIFT算法。